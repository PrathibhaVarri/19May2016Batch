package com.flp.fms.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;



import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.view.UserInteraction;

public class FilmServiceImpl implements IFilmService
{
	IFilmDao filmDao;
	
	public FilmServiceImpl() 
	{
		filmDao=new FilmDaoImplForDB();
	}
	
	public void addFilm(Map filmDetails) throws ParseException
	{
		Film film=new Film();
		film.setTitle((String) filmDetails.get(1));
		film.setDescription((String) filmDetails.get(2));
		film.setReleaseYear((Date) filmDetails.get(3));
		film.setRentalDuration( (Integer) filmDetails.get(4));
		film.setRental_rate((Double) filmDetails.get(5));
		film.setLength((Integer) filmDetails.get(6));
		film.setReplacementCost((Double) filmDetails.get(7));
		film.setRating((Double) filmDetails.get(8));
		film.setSpecialFeatures((String) filmDetails.get(9));
		
		Language lang=new Language((String) filmDetails.get(10));
		film.setLanguage(lang);
		
		Category catg=new Category((String) filmDetails.get(11));
		film.setCategory(catg);
		
		for(int i=12;i<filmDetails.size();i++)
		{
			Actor actor=new Actor();
			Map<Integer,Object> actorDetails=(Map) filmDetails.get(i);
			actor.setFirstName((String) actorDetails.get(1));
			actor.setLastName((String) actorDetails.get(2));
			film.getActors().add(actor);
		}
		
		filmDao.addFilm(film);
	}
	
	public String modifyFilm(Map<Integer, Object> filmList) throws ParseException
	{
		Film film=filmDao.searchFilm((Integer)filmList.get(1));
		if(film!=null){
		film.setTitle((String) filmList.get(2));
		film.setDescription((String) filmList.get(3));
		film.setReleaseYear((Date) filmList.get(4));
		film.setRentalDuration((Integer) filmList.get(5));
		film.setRental_rate((Double) filmList.get(6));
		film.setLength((Integer) filmList.get(7));
		film.setReplacementCost((Double) filmList.get(8));
		film.setRating((Double) filmList.get(9));
		film.setSpecialFeatures((String) filmList.get(10));
		 
		Language language=new Language();
		language.setName((String) filmList.get(11));
		film.setLanguage(language);
		 
		Category category=new Category();
		category.setName((String) filmList.get(12));
		film.setCategory(category);
		 
		 
		 
		 
		for(int i=13;i<filmList.size();i++)
		{
		Actor actor=new Actor();
		List actorDetails=(List) filmList.get(i);
		actor.setFirstName((String) actorDetails.get(0));
		actor.setLastName((String) actorDetails.get(1));
		film.getActors().add(actor);
		}
		 
		 
		 
		 
		filmDao.modifyFilm(film);
		return "success";
		 
		}
		else
		 
		 
		return null;
		}
		
	

	public boolean removeFilm(int filmId)
	{
		return filmDao.removeFilm(filmId);
	}

	public Film searchFilm(int filmId) 
	{
		return filmDao.searchFilm(filmId);
	}

	public List<Film> getAllFilm() 
	{
		return filmDao.getAllFilm();
	}

	

	
}

